<?php
    include("connect.php");
    include("includes/header.html");
    include("includes/adminnavbar.html");

  ?>
  <html>
  <style>
* {
  box-sizing: border-box;
}

.row {
  margin-left:-1vw;
  margin-right:-1vw;
}
  
.column {
  float: left;
  width: 50%;
  padding: 2vw;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
  margin-left: 3vw;
  align-content: center;
}

table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}
th{
    text-align: center;
  padding: 1vw;
}

td {
   text-align: left;
  padding: 1vw;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}
.spacing{
    margin-top: 2vw;
}
tr:hover
{
    background: lightslategrey;
}
.heading{
    font-size: 1vw;
    margin-top: 2vw;
    margin-right: 3vw;
    margin-left: 3vw;
    align-content: center;
}
</style>
<div class="heading"><h2>Registered Staff</h2></div>
  
  <div class="spacing"></div>
  <div class="row">
 <div class="column">
<table >
    <thead ">
        <tr class="tru">
            <th >ID</th>
            <th >Name</th>
            <th >Email</th>
            <th >user-Type</th>
            <th  colspan="2">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $sqlusers = "SELECT * FROM users WHERE TYPE='admin'";
            $usersresult = $conn ->query($sqlusers);
            while ($rows = mysqli_fetch_array($usersresult)) {?>
               
            
         
        <tr class="tru">
            <td ><?php echo $rows['id']?></td>
            <td ><?php echo $rows['firstname']?></td>
            <td ><?php echo $rows['email']?></td>
            <td ><?php echo $rows['type']?></td>
            <td >
                <a href="edituser.php?Id=<?php echo $rows["id"]?>">Edit</a>
            </td>
            <td>
                <a href="deleteuser.php?Id=<?php echo $rows["id"]?>">Delete</a>
            </td>
        </tr>
        <?php } ?>
    </tbody>

</table>
</div>
</div>
<div class="spacing"></div>

  </html>
  <?php include("includes/footer.html"); ?>