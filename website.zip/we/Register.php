<?php 

   	 	 global $errors; 
        $errors= array();
        include("connect.php");
        include("function.php");
        include("includes/header.html");
        include("includes/navbar.html");


if(isset($_POST['REGNEWUSER'])){

    $username    =  $_POST['name'];
	$email       =  $_POST['email'];
	$password_1  =  $_POST['pwd1'];
	$password_2  =  $_POST['pwd2'];

if (empty($username)) { 
		array_push($errors, "Username is required"); 
	}
	if (empty($email)) { 
		array_push($errors, "Email is required"); 
	}
	if (empty($password_1)) { 
		array_push($errors, "Password is required"); 
	}
	if ($password_1 != $password_2) {
		array_push($errors, "The two passwords do not match");
	}
    if(userexists($conn , $email)!==false) //check database if email is already in use
    {
        array_push($errors, "Email is Already Registered");
    }
    
    // register user if there are no errors in the form
	if (count($errors) == 0) {

		$password = password_hash($password_1, PASSWORD_DEFAULT);//encrypt the password before saving in the database

		
			$query = "INSERT INTO users (firstname, email, pwd, type) 
					  VALUES('$username', '$email', '$password', 'user' )";
			mysqli_query($conn, $query);

			// get id of the created user
			$logged_in_user_id = mysqli_insert_id($conn);

			$_SESSION['user'] = getUserById($logged_in_user_id); // put logged in user in session
			$_SESSION['success']  = "You are now logged in";
        $_SESSION["STATUS"] = true;
			header('location: index.php');
        echo "Success";
		}
	}
    






?>
<html>
<div class="header">
	<link rel="stylesheet" type="text/css" href="css/ADMIN.css">
	<h2>Register</h2>
</div>
<div class="log">
<form method="post" action="Register.php">
		<label>Firstname</label><br>
		<input class ="inputfield" type="text" name="name"><br><br>
		<label>Email</label><br>
		<input class ="inputfield"  type="email" name="email"><br><br>
		<label>Password</label><br>
		<input class ="inputfield" type="password" name="pwd1"><br><br>
		<label>Confirm password</label><br>
		<input  class ="inputfield" type="password" name="pwd2"><br><br>
		<br><button type="submit" class="btn" name="REGNEWUSER">Register</button>
	
	<p>
		Already a member? <a href="index.php?page=login">Sign in</a>
	</p>
    <div>
    <?php echo display_error(); ?>
    </div>
</form>
</div>
</html>
<?php include("includes/footer.html"); ?>

