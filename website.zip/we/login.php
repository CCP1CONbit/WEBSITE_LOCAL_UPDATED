<?php
     
        global $errors; 
        $errors= array();
        include("connect.php");
        include("function.php");

        if(isset($_POST['loginbtn'])) // CHECK IF THE BUTTON WASP PRESSED
        {

    
            $email    = $_POST['email']; //GET POSTERD EMAIL
            $password = $_POST['pwd'];    //GET POSTED PASSWORD FORM FORM
            
            if (empty($email)) //checks to see if user entered eamil
            { 
                 array_push($errors, "Email is required"); 
            }
            ////
            if (empty($password))  //checks to see if user entered password
            { 
                array_push($errors, "Password is required"); 
            }
            /////
            if (count($errors) == 0)
             {
                ////nested if
                login($conn, $email, $password); //if its a admin loggin in
               

        }//ends error if statement
            }//end main if statement

        include("includes/header.html");
        include("includes/navbar.html");

?>


<html>
<div class="header">
    <link rel="stylesheet" type="text/css" href="css/ADMIN.css">
    <h2>Log-in</h2>
</div>
    <div class="log">
    <form method="post" action="login.php">
        <label>Email:</label><br>
        <input class ="inputfield" type="text" name="email"  class="input"><br><br>
        <label>Password:</label><br>
        <input class ="inputfield" type="password" name="pwd"   class="input"><br><br>
      
        <br><button type="submit" name="loginbtn" class="btn" >Login</button><br><br>
        not registered?<a href="index.php?page=register">Click Here</a><br>
        </p> 
        <div>
                <?php echo display_error();?>
        </div>  
    </form>
    </div>
</html>

<?php include("includes/footer.html");?>


